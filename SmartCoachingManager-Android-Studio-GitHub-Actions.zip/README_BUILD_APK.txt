====================================================================
SMART COACHING MANAGER — ANDROID STUDIO READY PROJECT
====================================================================

এই জিপ ফাইলে Smart Coaching Manager-এর সম্পূর্ণ Android Studio প্রজেক্ট অন্তর্ভুক্ত রয়েছে।

★ মোবাইলে টেস্ট করার জন্য APK তৈরির সহজ নিয়ম (মাত্র ২ মিনিট):
--------------------------------------------------------------------
১. এই জিপ ফাইলটি আপনার কম্পিউটারে আনজিপ (Extract) করুন।
২. আপনার কম্পিউটারে "Android Studio" সফটওয়্যার ওপেন করুন।
   (যদি না থাকে, developer.android.com/studio থেকে নামিয়ে নিন)
৩. Android Studio-এর মেনু থেকে "Open" বা "File > Open" ক্লিক করুন।
৪. আনজিপ করা ফোল্ডারের ভেতরের "android" ফোল্ডারটি সিলেক্ট করুন এবং "OK" চাপুন।
৫. Android Studio স্বয়ংক্রিয়ভাবে Gradle সিঙ্ক করবে (১-২ মিনিট সময় লাগতে পারে)।
৬. সিঙ্ক শেষ হলে উপরের মেনু থেকে ক্লিক করুন:
   Build > Build Bundle(s) / APK(s) > Build APK(s)
৭. তৈরি হয়ে গেলে নিচে ডানপাশে "locate" বাটন আসবে।
   তাতে ক্লিক করলেই আপনি পেয়ে যাবেন:
   SmartCoachingManager-v2.5-b25-debug.apk
৮. এই APK ফাইলটি আপনার মোবাইলে নিয়ে ইনস্টল (Install) করে টেস্ট করুন!

প্রজেক্টের বিবরণ:
- Application ID: com.mohammadabsar.smartcoachingmanager
- App Name: Smart Coaching Manager
- Version: 2.5 (Version Code: 25)
- All Offline Storage & Persistence Configured
- Logo & Photos Base64 & IndexedDB Persistent

====================================================================
