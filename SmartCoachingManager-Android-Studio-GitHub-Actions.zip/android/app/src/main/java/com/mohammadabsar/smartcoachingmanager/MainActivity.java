package com.mohammadabsar.smartcoachingmanager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
